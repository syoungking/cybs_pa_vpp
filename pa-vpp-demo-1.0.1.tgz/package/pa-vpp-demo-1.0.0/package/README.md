# PA+VPP Demo 项目

## 项目介绍

本项目是一个运行PA+VPP的动态Demo网站，使用纯HTML + JavaScript + Express.js技术栈实现，包含完整的前后端分离架构。

## 技术栈

- **前端**：HTML5, JavaScript (ES6+), CSS3
- **后端**：Express.js, jsonwebtoken, cors
- **依赖**：JWT（HS256算法）、REST API调用、跨域、iframe嵌入

## 环境搭建

### 1. 安装依赖

```bash
npm install
```

### 2. 配置HTTPS证书

项目已内置自签名HTTPS证书，位于 `ssl` 目录：
- `ssl/key.pem`：私钥
- `ssl/cert.pem`：证书

### 3. 配置文件

配置文件位于 `config/app.properties`，包含以下配置项：

```properties
SANDBOX_SITE=https://centinelapistag.cardinalcommerce.com/
PROD_SITE=https://centinelapi.cardinalcommerce.com/
FIDO_INIT=V2/FIDO/Init
FIDO_CHALLENGE=V2/FIDO/Challenge
DDC_URL=V2/Cruise/Collect
DDC_RTN_URL=V2/Cruise/Return
JWT_API_KEY_ID=61a79c46a8bd2d6dd6ab521a
JWT_ORG_UNIT_ID=61a79c46a8bd2d6dd6ab5219
JWT_SECRET=af3aeed1-bac4-41f6-93e8-050eed0e1484
MERCHANT_ORIGIN=项目domain  # 配置页需提示用户替换为实际域名
RETURN_URL=项目接收回调的url  # 配置页需提示用户替换为实际回调URL
DDC_RETURN_URL=项目接收DDC回调的url  # 配置页需提示用户替换为实际DDC回调URL
```

**注意**：首次运行时，系统会检查配置完整性，若配置不完整会自动跳转到配置页面，请根据实际情况修改配置项。

## 启动步骤

### 启动服务器

```bash
npm start
```

服务器将在 `https://localhost:443` 上运行。

### 访问项目

打开浏览器，访问 `https://localhost:443`：
- 首次访问会跳转到配置页面，请填写完整的配置信息
- 配置完成后，会自动跳转到首页
- 在首页可选择环境（Sandbox/Production），并点击 "Compatibility Check" 按钮执行流程

## 功能说明

### 1. 配置管理

- 支持查看和编辑所有配置项
- 配置持久化到 `config/app.properties` 文件
- 配置不完整时会强制跳转到配置页面

### 2. Compatibility Check 流程

1. 选择环境（Sandbox/Production）
2. 点击 "Compatibility Check" 按钮
3. 系统生成JWT并通过iframe提交到Cardinal Commerce
4. 接收回调并验证JWT
5. 显示请求和应答信息
6. 根据错误码显示结果

### 3. DDC (Device Data Collection) 流程

1. 在DDC文本框中输入JWT或JSON payload
2. 如果输入JSON，系统会解析其中的`consumerAuthenticationInformation.accessToken`字段获取JWT
3. 点击 "DDC" 按钮
4. 系统通过隐藏的iframe提交表单到Cardinal Commerce的DDC端点
5. 系统设置10秒超时，超时后显示"设备信息采集超时"
6. 接收回调后，根据ActionCode判断：
   - ActionCode=SUCCESS：显示"设备信息采集成功"
   - 其他情况：显示"设备信息采集失败"
7. 回调的payload会显示在DDC文本框中

### 4. 异常处理

- JWT生成失败：显示错误信息
- API调用超时/失败：显示错误信息
- JWT验签失败：显示错误信息
- 回调接收异常：显示错误信息
- 配置缺失：强制跳转到配置页面

## 项目结构

```
PAVPP-Project/
├── public/            # 前端静态文件
│   ├── css/          # 样式文件
│   │   └── styles.css
│   ├── js/           # JavaScript文件
│   │   └── app.js
│   ├── index.html    # 主页面
│   └── fido-form.html # FIDO表单页面
├── config/            # 配置文件
│   └── app.properties # 应用配置
├── server/            # 后端代码
│   ├── configManager.js # 配置管理
│   └── jwtManager.js  # JWT管理
├── ssl/               # HTTPS证书
│   ├── key.pem        # 私钥
│   └── cert.pem       # 证书
├── server.js          # 服务器入口
├── package.json       # 项目配置
└── README.md          # 项目说明
```

## 注意事项

1. 本项目使用自签名HTTPS证书，浏览器可能会提示安全警告，请选择 "继续访问"。
2. 请确保 `MERCHANT_ORIGIN` 和 `RETURN_URL` 配置正确，否则可能导致回调失败。
3. 本项目仅用于Demo目的，生产环境请使用正式的HTTPS证书和配置。