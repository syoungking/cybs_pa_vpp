const fs = require('fs');
const path = require('path');
const PropertiesReader = require('properties-reader');

const configPath = path.join(__dirname, '..', 'config', 'app.properties');

// 读取配置
const readConfig = () => {
  try {
    if (!fs.existsSync(configPath)) {
      throw new Error('配置文件不存在');
    }
    
    const properties = PropertiesReader(configPath);
    return {
      SANDBOX_SITE: properties.get('SANDBOX_SITE'),
      PROD_SITE: properties.get('PROD_SITE'),
      FIDO_INIT: properties.get('FIDO_INIT'),
      FIDO_CHALLENGE: properties.get('FIDO_CHALLENGE'),
      DDC_URL: properties.get('DDC_URL'),
      JWT_API_KEY_ID: properties.get('JWT_API_KEY_ID'),
      JWT_ORG_UNIT_ID: properties.get('JWT_ORG_UNIT_ID'),
      JWT_SECRET: properties.get('JWT_SECRET'),
      MERCHANT_ORIGIN: properties.get('MERCHANT_ORIGIN'),
      RETURN_URL: properties.get('RETURN_URL')
    };
  } catch (error) {
    console.error('读取配置文件失败:', error);
    throw error;
  }
};

// 写入配置
const writeConfig = (config) => {
  try {
    let content = '';
    Object.entries(config).forEach(([key, value]) => {
      content += `${key}=${value}\n`;
    });
    
    fs.writeFileSync(configPath, content);
    return true;
  } catch (error) {
    console.error('写入配置文件失败:', error);
    throw error;
  }
};

// 检查配置完整性
const checkConfigComplete = () => {
  try {
    const config = readConfig();
    const requiredFields = [
      'SANDBOX_SITE', 'PROD_SITE', 'FIDO_INIT', 'FIDO_CHALLENGE',
      'DDC_URL',
      'JWT_API_KEY_ID', 'JWT_ORG_UNIT_ID', 'JWT_SECRET', 'MERCHANT_ORIGIN', 'RETURN_URL'
    ];
    
    for (const field of requiredFields) {
      if (!config[field]) {
        return false;
      }
    }
    
    return true;
  } catch (error) {
    return false;
  }
};

module.exports = {
  readConfig,
  writeConfig,
  checkConfigComplete
};